---
title: Nawaqes
emoji: 📢
colorFrom: orange
colorTo: amber
sdk: docker
app_port: 7860
pinned: false
license: mit
---

# Nawaqes — منصة الإعلانات الذكية المتكاملة

Production deployment of Nawaqes. The Dockerfile builds the Vite + Express
app and runs it on port 7860.

## Live URL
- App: https://safwatkhokha-nawaqes.hf.space
- Health: https://safwatkhokha-nawaqes.hf.space/api/health

## Configuration
All secrets are set as HF Spaces Variables/Secrets. See `.env.example` for the full list.
